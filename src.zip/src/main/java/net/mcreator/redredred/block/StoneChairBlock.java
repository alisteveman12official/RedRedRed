package net.mcreator.redredred.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.util.RandomSource;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.redredred.init.RedredredModBlocks;

import java.util.function.Function;
import java.util.function.Consumer;

public class StoneChairBlock extends Block implements SimpleWaterloggedBlock {
	public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
	public static final BooleanProperty POTATO = BooleanProperty.create("potato");
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public StoneChairBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(3.6f, 22.5f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(POTATO, false).setValue(WATERLOGGED, false));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			if (state.getValue(POTATO) == true) {
				return switch (state.getValue(FACING)) {
					default -> Shapes.or(box(14, 0, 14, 16, 14, 16), box(0, 0, 14, 2, 14, 16), box(14, 0, 0, 16, 14, 2), box(0, 0, 0, 2, 14, 2), box(0, 14, 0, 16, 16, 16), box(0, 16, 0, 16, 32, 2));
					case NORTH -> Shapes.or(box(0, 0, 0, 2, 14, 2), box(14, 0, 0, 16, 14, 2), box(0, 0, 14, 2, 14, 16), box(14, 0, 14, 16, 14, 16), box(0, 14, 0, 16, 16, 16), box(0, 16, 14, 16, 32, 16));
					case EAST -> Shapes.or(box(14, 0, 0, 16, 14, 2), box(14, 0, 14, 16, 14, 16), box(0, 0, 0, 2, 14, 2), box(0, 0, 14, 2, 14, 16), box(0, 14, 0, 16, 16, 16), box(0, 16, 0, 2, 32, 16));
					case WEST -> Shapes.or(box(0, 0, 14, 2, 14, 16), box(0, 0, 0, 2, 14, 2), box(14, 0, 14, 16, 14, 16), box(14, 0, 0, 16, 14, 2), box(0, 14, 0, 16, 16, 16), box(14, 16, 0, 16, 32, 16));
				};
			}
			return switch (state.getValue(FACING)) {
				default -> Shapes.or(box(14, 0, 14, 16, 14, 16), box(0, 0, 14, 2, 14, 16), box(14, 0, 0, 16, 14, 2), box(0, 0, 0, 2, 14, 2), box(0, 14, 0, 16, 16, 16), box(0, 16, 0, 16, 32, 2));
				case NORTH -> Shapes.or(box(0, 0, 0, 2, 14, 2), box(14, 0, 0, 16, 14, 2), box(0, 0, 14, 2, 14, 16), box(14, 0, 14, 16, 14, 16), box(0, 14, 0, 16, 16, 16), box(0, 16, 14, 16, 32, 16));
				case EAST -> Shapes.or(box(14, 0, 0, 16, 14, 2), box(14, 0, 14, 16, 14, 16), box(0, 0, 0, 2, 14, 2), box(0, 0, 14, 2, 14, 16), box(0, 14, 0, 16, 16, 16), box(0, 16, 0, 2, 32, 16));
				case WEST -> Shapes.or(box(0, 0, 14, 2, 14, 16), box(0, 0, 0, 2, 14, 2), box(14, 0, 14, 16, 14, 16), box(14, 0, 0, 16, 14, 2), box(0, 14, 0, 16, 16, 16), box(14, 16, 0, 16, 32, 16));
			};
		}, WATERLOGGED);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state) {
		return propagatesSkylightDown(state) ? 0 : 1;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, POTATO, WATERLOGGED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(POTATO, false).setValue(WATERLOGGED, flag);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, LevelReader world, ScheduledTickAccess scheduledTickAccess, BlockPos currentPos, Direction facing, BlockPos facingPos, BlockState facingState, RandomSource random) {
		if (state.getValue(WATERLOGGED)) {
			scheduledTickAccess.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, world, scheduledTickAccess, currentPos, facing, facingPos, facingState, random);
	}

	public static class Item extends BlockItem {
		public Item(Item.Properties properties) {
			super(RedredredModBlocks.STONE_CHAIR.get(), properties);
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			componentConsumer.accept(Component.translatable("block.redredred.stone_chair.description_0"));
			componentConsumer.accept(Component.translatable("block.redredred.stone_chair.description_1"));
		}
	}
}