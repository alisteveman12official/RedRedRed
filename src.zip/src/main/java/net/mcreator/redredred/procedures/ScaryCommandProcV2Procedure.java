package net.mcreator.redredred.procedures;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.redredred.init.RedredredModAttributes;
import net.mcreator.redredred.RedredredMod;

public class ScaryCommandProcV2Procedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		{
			Entity _ent = entity;
			Scoreboard _sc = _ent.level().getScoreboard();
			Objective _so = _sc.getObjective("cheating_value");
			if (_so == null)
				_so = _sc.addObjective("cheating_value", ObjectiveCriteria.DUMMY, Component.literal("cheating_value"), ObjectiveCriteria.RenderType.INTEGER, true, null);
			_sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()), _so).set(1);
		}
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("...It's too late. You wanted to cheat? let's see what happens if I CHEAT..."), false);
		if (entity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
			AdvancementHolder _adv = _level.getServer().getAdvancements().get(ResourceLocation.parse("redredred:never_mind_why_did_i_do_that"));
			if (_adv != null) {
				AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
				if (!_ap.isDone()) {
					for (String criteria : _ap.getRemainingCriteria())
						_player.getAdvancements().award(_adv, criteria);
				}
			}
		}
		RedredredMod.queueServerWork(20, () -> {
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-100), AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(Attributes.LUCK).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.LUCK).addPermanentModifier(modifier);
				}
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-19), AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(Attributes.MAX_HEALTH).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.MAX_HEALTH).addPermanentModifier(modifier);
				}
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-20), AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(Attributes.ARMOR).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.ARMOR).addPermanentModifier(modifier);
				}
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-40), AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(Attributes.ATTACK_SPEED).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.ATTACK_SPEED).addPermanentModifier(modifier);
				}
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), 1, AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(RedredredModAttributes.LOSER_SCORE).hasModifier(modifier.id())) {
					_entity.getAttribute(RedredredModAttributes.LOSER_SCORE).addPermanentModifier(modifier);
				}
			}
		});
	}
}