package net.mcreator.redredred.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.redredred.RedredredMod;

public class NoProcProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("no"), false);
		RedredredMod.LOGGER.info("[RedRedRed] [prankies] Executed no.");
		RedredredMod.LOGGER.debug("REDREDRED_EXECUTENO");
	}
}