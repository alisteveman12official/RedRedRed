package net.mcreator.redredred.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

public class LeviBlockRedstoneOnProcedure {
	public static void execute(LevelAccessor world) {
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("RedRedRed joined the game").withColor(0xffff00), false);
		}
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<RedRedRed> soo someone decided to use redstone on the LeviBlock... it does nothing lol."), false);
		}
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<RedRedRed> OR DOES IT???").withColor(0xff0000).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.ITALIC), false);
		}
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("RedRedRed left the game").withColor(0xffff00), false);
		}
	}
}